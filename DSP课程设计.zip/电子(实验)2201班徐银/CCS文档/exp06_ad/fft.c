#include "csl.h"
#include "csl_pll.h"
#include "csl_chip.h"
#include "csl_gpio.h"
#include "math.h"



#define ad_cs_1   out_data|=0x0002; GPIO_RSET(AGPIODATA,out_data);      //A2
#define ad_cs_0   out_data&=0xfffd; GPIO_RSET(AGPIODATA,out_data);

#define ad_in_1   out_data|=0x0004; GPIO_RSET(AGPIODATA,out_data);      //A1
#define ad_in_0   out_data&=0xfffb; GPIO_RSET(AGPIODATA,out_data);

#define ad_clk_1  out_data|=0x0008; GPIO_RSET(AGPIODATA,out_data);      //A4
#define ad_clk_0  out_data&=0xfff7; GPIO_RSET(AGPIODATA,out_data);

Uint16 out_data=0;
Uint16 get_data=0;
Uint16 data_buff[256];


//fft����
double pr[256],pi[256],fr[256],fi[256]; //ʵ��databuffer=pr �鲿=0=pi���룬fr��fi�����n256��k8�����������1
int xm,zm;
int n=256;

Uint16 ad_out(void)
{
    get_data=GPIO_RGET(AGPIODATA);
    get_data&=0x0010;
    if(get_data==0x0010)
        return 1;
    else
        return 0;
}

void delay(Uint32 t)
{
    Uint32 i=0,j=0;
    for(i=0;i<t;i++)
        for(j=0;j<0xf;j++);
}

void gpio_init(void)
{
    *(ioport volatile unsigned int *)0x6c00=0x0011;
    CHIP_RSET(XBSR,0x0a00);     //  0x0a03,Ҳ���Խ�A0--A13 ���ó� GPIO
    GPIO_RSET(AGPIOEN,0xffff);
    GPIO_RSET(AGPIODIR,0xffef);
}

PLL_Config my_config={
    0,
    1,
    24,
    1
};

Uint16 get_vol(unsigned int port)
{
    Uint16 value=0,i=0;

    port<<=4;
    ad_cs_0
    delay(2);
    ad_clk_0
    delay(2);

    for(i=0;i<12;i++)
    {
        value<<=1;
        if(ad_out())
        {
            value|=0x01;
        }

        if((port&0x80)==0x80)
        {
            ad_in_1;
            delay(2);
        }

        else
        {
            ad_in_0
            delay(2);
        }

        ad_clk_1
        delay(2);
        ad_clk_0
        delay(2);
        port<<=1;
    }

    ad_cs_1
    delay(2);

    return value;

}

/////////////////////////////////FFT/////////////////////////////////////////////
void kfft(pr,pi,n,k,fr,fi,l,il)
  int n,k,l,il;
  double pr[],pi[],fr[],fi[];

  { int it,m,is,i,j,nv,l0;
    double p,q,s,vr,vi,poddr,poddi;

    for (it=0; it<=n-1; it++)
      { m=it; is=0;
        for (i=0; i<=k-1; i++)
          { j=m/2; is=2*is+(m-2*j); m=j;}
        fr[it]=pr[is]; fi[it]=pi[is];
      }
    pr[0]=1.0; pi[0]=0.0;
    p=6.283185306/(1.0*n);
    pr[1]=cos(p); pi[1]=-sin(p);
    if (l!=0) pi[1]=-pi[1];
    for (i=2; i<=n-1; i++)
      { p=pr[i-1]*pr[1]; q=pi[i-1]*pi[1];
        s=(pr[i-1]+pi[i-1])*(pr[1]+pi[1]);
        pr[i]=p-q; pi[i]=s-p-q;
      }
    for (it=0; it<=n-2; it=it+2)
      { vr=fr[it]; vi=fi[it];
        fr[it]=vr+fr[it+1]; fi[it]=vi+fi[it+1];
        fr[it+1]=vr-fr[it+1]; fi[it+1]=vi-fi[it+1];
      }
    m=n/2; nv=2;
    for (l0=k-2; l0>=0; l0--)
      { m=m/2; nv=2*nv;
        for (it=0; it<=(m-1)*nv; it=it+nv)
          for (j=0; j<=(nv/2)-1; j++)
            { p=pr[m*j]*fr[it+j+nv/2];
              q=pi[m*j]*fi[it+j+nv/2];
              s=pr[m*j]+pi[m*j];
              s=s*(fr[it+j+nv/2]+fi[it+j+nv/2]);
              poddr=p-q; poddi=s-p-q;
              fr[it+j+nv/2]=fr[it+j]-poddr;
              fi[it+j+nv/2]=fi[it+j]-poddi;
              fr[it+j]=fr[it+j]+poddr;
              fi[it+j]=fi[it+j]+poddi;
            }
      }
    if (l!=0)
      for (i=0; i<=n-1; i++)
        { fr[i]=fr[i]/(1.0*n);
          fi[i]=fi[i]/(1.0*n);
        }
    if (il!=0)
      for (i=0; i<=n-1; i++)
        { pr[i]=sqrt(fr[i]*fr[i]+fi[i]*fi[i]);
          if (fabs(fr[i])<0.000001*fabs(fi[i]))
            { if ((fi[i]*fr[i])>0) pi[i]=90.0;
              else pi[i]=-90.0;
            }
          else
            pi[i]=atan(fi[i]/fr[i])*360.0/6.283185306;
        }


   }
//////////////////////////////////////////////////////////////////

void main(void)
{
    Uint16 i=0;
    CSL_init();
    PLL_config(&my_config);
    gpio_init();
    ad_cs_1;
    delay(2);
    ad_clk_1
    delay(2);
    while(1)
    {
        //fft
        double all1=0;
        double n1=0,pn1=0;
        double n2=0,pn2=0;

        for(i=0;i<256;i++)
        {
            data_buff[i]=get_vol(0x00);
            delay(1);
        }

        for (i=0; i<=n-1; i++)
        {
            pr[i]=data_buff[i];
            pi[i]=0;
            all1=all1+pr[i];
        }
        all1=all1/n;
        for (i=0; i<=n-1; i++)
        {
           pr[i]=pr[i]-all1;
        }

        //----------------------------FFT����----------------------------------------
        kfft(pr,pi,256,8,fr,fi,0,1);  //����ģ��pr������pi����ͼ��pr��32float
        int exclude_range = 5; // �ų���Χ�İ뾶
        double pn1 = -INFINITY, pn2 = -INFINITY;
        int n1 = -1, n2 = -1;
        for (i = 0; i < 128; i++) {
            if (pr[i] > pn1) {
                // ���µڶ���ֵΪԭ��һ��ֵ
                if (n1 != -1 && abs(i - n1) > exclude_range) {
                    pn2 = pn1;
                    n2 = n1;
                }
                pn1 = pr[i];// ���µ�һ��ֵ
                n1 = i;
            } else if (pr[i] > pn2 && abs(i - n1) > exclude_range) {
                pn2 = pr[i];// ���µڶ���ֵ
                n2 = i;
            }
        }

        delay(2);  //���öϵ�۲�ͼ��
    }
}
