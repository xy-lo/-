// lowpass.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <string.h>


#define pi ((double)3.1415926)

struct DESIGN_SPECIFICATION
{
    double Cotoff;
    double Stopband;
    double Stopband_attenuation;
};

typedef struct
{
    double Real_part;
    double Imag_Part;
}COMPLEX;



int Ceil(double input)
{
     if(input != (int)input)
	 {
		 return ((int)input) +1;
	 }
     else
	 {
		 return ((int)input);
	 }
}

void init_array(double *array, int N)
{
	int i=0;
	for(i=0;i<N;i++)
	{
		array[i]=0;
	}
}

void init_struct(COMPLEX *str, int N)
{
	int i=0;
	for(i=0;i<N;i++)
	{
		str[i].Imag_Part=0;
		str[i].Real_part=0;
	}
}


int Complex_Multiple(COMPLEX a,COMPLEX b,double *Res_Real,double *Res_Imag)
{
       *(Res_Real) =  (a.Real_part)*(b.Real_part) - (a.Imag_Part)*(b.Imag_Part);
       *(Res_Imag) =  (a.Imag_Part)*(b.Real_part) + (a.Real_part)*(b.Imag_Part);
	 return (int)1;
}


int Buttord(double Cotoff, double Stopband, double Stopband_attenuation)
{
   int N;

   printf("Wc =  %lf  [rad/sec] \n" ,Cotoff);
   printf("Ws =  %lf  [rad/sec] \n" ,Stopband);
   printf("As =  %lf  [dB] \n" ,Stopband_attenuation);
   printf("--------------------------------------------------------\n" );

   N = Ceil(0.5*(log10(pow (10, Stopband_attenuation/10) - 1) / log10 (Stopband/Cotoff) ));
   return (int)N;
}

int Butter(int N, double Cotoff,double *a,double *b)
{
    double dk = 0;
    int k = 0;
    int count = 0,count_1 = 0;
    COMPLEX *poles;
    COMPLEX *Res,*Res_Save;

	poles = (COMPLEX*)malloc(N*sizeof(COMPLEX));
	Res = (COMPLEX*)malloc((N+1)*sizeof(COMPLEX));
	Res_Save = (COMPLEX*)malloc((N+1)*sizeof(COMPLEX));

	init_struct(poles,N);
	init_struct(Res,N+1);
	init_struct(Res_Save,N+1);

    if((N%2) == 0) dk = 0.5;
    else dk = 0;

    for(k = 0;k <= ((2*N)-1) ; k++)
    {
         if(Cotoff*cos((k+dk)*(pi/N)) < 0)
         {
              poles[count].Real_part = -Cotoff*cos((k+dk)*(pi/N));
			  poles[count].Imag_Part= -Cotoff*sin((k+dk)*(pi/N));
              count++;
	        if(count == N)
				break;
         }
    }

     printf("Pk =   \n" );
     for(count = 0;count < N ;count++)
     {
           printf("(%lf) + (%lf i) \n" ,-poles[count].Real_part,-poles[count].Imag_Part);
     }
     printf("--------------------------------------------------------\n" );

     Res[0].Real_part = poles[0].Real_part;
     Res[0].Imag_Part= poles[0].Imag_Part;

     Res[1].Real_part = 1;
     Res[1].Imag_Part= 0;

    for(count_1 = 0;count_1 < N-1;count_1++)
    {
	     for(count = 0;count <= count_1 + 2;count++)
	     {
	          if(0 == count)
			  {
 	                Complex_Multiple(Res[count], poles[count_1+1],&(Res_Save[count].Real_part), &(Res_Save[count].Imag_Part));
			   //printf( "Res_Save : (%lf) + (%lf i) \n" ,Res_Save[0].Real_part,Res_Save[0].Imag_Part);
	          }

	          else if((count_1 + 2) == count)
	          {
	                 Res_Save[count].Real_part  += Res[count - 1].Real_part;
					 Res_Save[count].Imag_Part += Res[count - 1].Imag_Part;
	          }
		      else
			  {
 	                 Complex_Multiple(Res[count], poles[count_1+1],	&(Res_Save[count].Real_part), &(Res_Save[count].Imag_Part));

                       //printf( "Res          : (%lf) + (%lf i) \n" ,Res[count - 1].Real_part,Res[count - 1].Imag_Part);
			    //printf( "Res_Save : (%lf) + (%lf i) \n" ,Res_Save[count].Real_part,Res_Save[count].Imag_Part);

			    Res_Save[count].Real_part  += Res[count - 1].Real_part;
			    Res_Save[count].Imag_Part += Res[count - 1].Imag_Part;

			    //printf( "Res_Save : (%lf) + (%lf i) \n" ,Res_Save[count].Real_part,Res_Save[count].Imag_Part);

		    }
		    //printf("There \n" );
	     }

	     for(count = 0;count <= N;count++)
	     {
	           Res[count].Real_part = Res_Save[count].Real_part;
               Res[count].Imag_Part= Res_Save[count].Imag_Part;

			   *(a + N - count) = Res[count].Real_part;
	     }

	     //printf("There!! \n" );

    	}

     *(b+N) = *(a+N);

     //------------------------display---------------------------------//
     printf("bs =  [" );
     for(count = 0;count <= N ;count++)
     {
           printf("%lf ", *(b+count));
     }
     printf(" ] \n" );

     printf("as =  [" );
     for(count = 0;count <= N ;count++)
     {
           printf("%lf ", *(a+count));
     }
     printf(" ] \n" );

     printf("--------------------------------------------------------\n" );

	 free(poles);
	 free(Res);
	 free(Res_Save);
     return (int) 1;
}

// the function is to change from analog lowpass filter to analog higpass filter, the relation is s_low=cutof_low*cutof_high/s_high
int analogLowToHigh(int N, double *as_low, double *bs_low, double *as_high, double *bs_high, double cutoff_low, double cutoff_high)
{
	double res;
	int count;

	res = cutoff_low*cutoff_high;

	for(count=0;count<=N;count++)
	{
		*(as_high+count) = (*(as_low+N-count))*pow(res,count);
		*(bs_high+count) = (*(bs_low+N-count))*pow(res,count);
	}
	return (int) 1;
}

// the function is to calculate the combination,C(n,m), where n>=m
int combination(int n, int m)
{
	int isum=1;
	int k =1;
	for(k=1;k<=m;k++)
	{
		isum=(isum*(n-m+k))/k;//����˷����������㣨m-n+k��/k�������������
	}
	return isum;
}

// the function is to spred binomial theorem(����ʽ������չ��),papa*(s^2+k)^n*s^offset, where n is the filter order
int binomialSpread(double * coeff, int N, double k, int offset, double para)
{
	int i=0;
	double xishu=0;
	for(i=0;i<=N;i++)
	{
		xishu = combination(N,i)*pow(k,i);
		*(coeff+2*(N-i)+offset) += para*xishu;
	}
	return (int) 1;
}


// the function is to change analog lowpass filter to analog bandpass filter, s_low=s_pass+k/s_pass, where k is the center frequency of bandpass filter
int analogLowToband(int N, double *as_low, double *bs_low, double *as_pass, double *bs_pass, double centerFre)
{
	int i=0;
	for(i=0; i<=N;i++)
	{
		binomialSpread(as_pass,N,centerFre,i,*(as_low+i));
		binomialSpread(bs_pass,N,centerFre,i,*(bs_low+i));
	}
	return (int) 1;
}


int Bilinear(int N, double *as,double *bs, double *az,double *bz)
{
    int Count = 0,Count_1 = 0,Count_2 = 0,Count_Z = 0;
    double *Res;
	double *Res_Save;

	Res = (double*)malloc((N+1)*sizeof(double));
	Res_Save = (double*)malloc((N+1)*sizeof(double));

	init_array(Res,N+1);
	init_array(Res_Save,N+1);
    for(Count_Z = 0;Count_Z <= N;Count_Z++)
	{
         *(az+Count_Z)  = 0;
		 *(bz+Count_Z)  = 0;
	}


	for(Count = 0;Count<=N;Count++)
	{
	      for(Count_Z = 0;Count_Z <= N;Count_Z++)
	      {
	      	     Res[Count_Z] = 0;
				 Res_Save[Count_Z] = 0;
	      }
          Res_Save [0] = 1;

	      for(Count_1 = 0; Count_1 < N-Count;Count_1++)
	      {
				for(Count_2 = 0; Count_2 <= Count_1+1;Count_2++)
	      		{
	      		     if(Count_2 == 0)
					 {
						 Res[Count_2] += Res_Save[Count_2];
				     //printf( "Res[%d] %lf  \n" , Count_2 ,Res[Count_2]);
					 }

					 else if((Count_2 == (Count_1+1))&&(Count_1 != 0))
					{
			           Res[Count_2] += -Res_Save[Count_2 - 1];
                              //printf( "Res[%d] %lf  \n" , Count_2 ,Res[Count_2]);
					}

					else
					{
			           Res[Count_2] += Res_Save[Count_2] - Res_Save[Count_2 - 1];
				    //printf( "Res[%d] %lf  \n" , Count_2 ,Res[Count_2]);
					}
				}

                   	//printf( "Res : ");
				for(Count_Z = 0;Count_Z<= N;Count_Z++)
				{
 		             Res_Save[Count_Z]  =  Res[Count_Z] ;
					Res[Count_Z]  = 0;
					//printf( "[%d]  %lf  " ,Count_Z, Res_Save[Count_Z]);
				}
		      //printf(" \n" );

	      	}

		for(Count_1 = (N-Count); Count_1 < N;Count_1++)
	    {
                for(Count_2 = 0; Count_2 <= Count_1+1;Count_2++)
	      		{
	      		    if(Count_2 == 0)
					{
						Res[Count_2] += Res_Save[Count_2];
						 //printf( "Res[%d] %lf  \n" , Count_2 ,Res[Count_2]);
					}

					else if((Count_2 == (Count_1+1))&&(Count_1 != 0))
					{
			           Res[Count_2] += Res_Save[Count_2 - 1];
                              //printf( "Res[%d] %lf  \n" , Count_2 ,Res[Count_2]);
					}

					else
					{
			           Res[Count_2] += Res_Save[Count_2] + Res_Save[Count_2 - 1];
				     //printf( "Res[%d] %lf  \n" , Count_2 ,Res[Count_2]);
					}
				}

                   //	printf( "Res : ");
		      for(Count_Z = 0;Count_Z<= N;Count_Z++)
		      {
 		             Res_Save[Count_Z]  =  Res[Count_Z] ;
			       Res[Count_Z]  = 0;
				//printf( "[%d]  %lf  " ,Count_Z, Res_Save[Count_Z]);
		      }
		       //printf(" \n" );
	      	}


             //printf( "Res : ");
		for(Count_Z = 0;Count_Z<= N;Count_Z++)
		{
                    *(az+Count_Z) +=  pow(2,N-Count)  *  (*(as+Count)) * Res_Save[Count_Z];
			 *(bz+Count_Z) +=  (*(bs+Count)) * Res_Save[Count_Z];
                     //printf( "  %lf  " ,*(bz+Count_Z));
		 }
		 //printf(" \n" );

	}

     for(Count_Z = N;Count_Z >= 0;Count_Z--)
     {
          *(bz+Count_Z) =  (*(bz+Count_Z))/(*(az+0));
          *(az+Count_Z) =  (*(az+Count_Z))/(*(az+0));
     }

	//------------------------display---------------------------------//
      printf("bz =  [" );
      for(Count_Z= 0;Count_Z <= N ;Count_Z++)
      {
           printf("%lf ", *(bz+Count_Z));
      }
      printf(" ] \n" );
      printf("az =  [" );
      for(Count_Z= 0;Count_Z <= N ;Count_Z++)
      {
           printf("%lf ", *(az+Count_Z));
      }
      printf(" ] \n" );
      printf("--------------------------------------------------------\n" );

	 free(Res);
	 free(Res_Save);
	 return (int) 1;
}


int main(void)
{
     int count;

     struct DESIGN_SPECIFICATION IIR_Filter;

     IIR_Filter.Cotoff = (double)(pi/2);         //[red]
     IIR_Filter.Stopband = (double)((pi*3)/4);   //[red]
     IIR_Filter.Stopband_attenuation = 30;        //[dB]

     int N;

     IIR_Filter.Cotoff = 2 * tan((IIR_Filter.Cotoff)/2);            //[red/sec]
     IIR_Filter.Stopband = 2 * tan((IIR_Filter.Stopband)/2);   //[red/sec]

     N = Buttord(IIR_Filter.Cotoff, IIR_Filter.Stopband, IIR_Filter.Stopband_attenuation);
     printf("N:  %d  \n" ,N);
     printf("--------------------------------------------------------\n" );

     double *as, *bs;
	 as = (double*)malloc((N+1)*sizeof(double));
	 bs = (double*)malloc((N+1)*sizeof(double));

	init_array(as,N+1);
	init_array(bs,N+1);

     Butter(N, IIR_Filter.Cotoff, as, bs);

     double *az, *bz;
 	 az = (double*)malloc((N+1)*sizeof(double));
	 bz = (double*)malloc((N+1)*sizeof(double));
	 init_array(az,N+1);
     init_array(bz,N+1);

     Bilinear(N, as,bs, az,bz);

	 free(as);
	 free(bs);
	 free(az);
	 free(bz);
     printf("Finish \n" );
     return (int)0;
}
