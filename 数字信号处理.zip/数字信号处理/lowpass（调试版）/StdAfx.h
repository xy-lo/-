// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__24DA3384_DB3A_40E6_91B6_204FB139691B__INCLUDED_)
#define AFX_STDAFX_H__24DA3384_DB3A_40E6_91B6_204FB139691B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__24DA3384_DB3A_40E6_91B6_204FB139691B__INCLUDED_)
